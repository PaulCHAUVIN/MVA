# lab-session-generative-modeling

Run `pip install -r requirements.txt` before running the notebooks.
